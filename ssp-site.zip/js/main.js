(function () {
  var burger = document.querySelector('.burger');
  var menu = document.getElementById('menu');
  burger.addEventListener('click', function () {
    var open = menu.classList.toggle('open');
    burger.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  menu.addEventListener('click', function (e) {
    if (e.target.tagName === 'A') { menu.classList.remove('open'); burger.setAttribute('aria-expanded', 'false'); }
  });

  document.getElementById('yr').textContent = new Date().getFullYear();

  var form = document.getElementById('enquiry');
  var status = form.querySelector('.status');
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    status.className = 'status';
    var f = form.elements;
    if (!f.name.value.trim() || !f.email.value.trim() || !f.service.value || !f.message.value.trim()) {
      status.className = 'status err';
      status.textContent = 'Please fill in your name, email, service of interest and project details.';
      return;
    }
    var btn = form.querySelector('button');
    btn.disabled = true;
    status.textContent = 'Sending...';
    fetch(form.action, { method: 'POST', body: new FormData(form) })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (d.ok) {
          status.className = 'status ok';
          status.textContent = 'Thank you. We have your enquiry and will reply within two working days.';
          form.reset();
        } else { throw new Error(d.error || 'fail'); }
      })
      .catch(function () {
        status.className = 'status err';
        status.textContent = 'Could not send. Please email us directly at info@seruyasp.co.ke.';
      })
      .finally(function () { btn.disabled = false; });
  });
})();

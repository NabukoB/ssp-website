<?php
// Contact form handler for Hostinger shared hosting.
// 1) Change $to to the inbox that should receive enquiries.
// 2) Change $from to an email address on YOUR domain (e.g. info@seruyasp.co.ke).
//    Create it in hPanel > Emails so messages are not marked as spam.
$to   = 'info@seruyasp.co.ke';
$from = 'info@seruyasp.co.ke';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['ok'=>false]); exit; }
// Honeypot: bots fill this in, people never see it.
if (!empty($_POST['website'])) { echo json_encode(['ok'=>true]); exit; }

function clean($v){ return trim(str_replace(["\r","\n"], ' ', strip_tags((string)$v))); }

$name    = clean($_POST['name']    ?? '');
$org     = clean($_POST['org']     ?? '');
$email   = clean($_POST['email']   ?? '');
$service = clean($_POST['service'] ?? '');
$message = trim(strip_tags((string)($_POST['message'] ?? '')));

if ($name === '' || $message === '' || $service === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
  http_response_code(400); echo json_encode(['ok'=>false,'error'=>'invalid']); exit;
}

$subject = "SSP website enquiry: $service";
$body = "Name: $name\nOrganisation: $org\nEmail: $email\nService of interest: $service\n\nProject:\n$message\n";
$headers = "From: Seruya Website <$from>\r\nReply-To: $name <$email>\r\nContent-Type: text/plain; charset=utf-8\r\n";

$sent = mail($to, '=?UTF-8?B?'.base64_encode($subject).'?=', $body, $headers);
if (!$sent) { http_response_code(500); echo json_encode(['ok'=>false,'error'=>'mail']); exit; }
echo json_encode(['ok'=>true]);
